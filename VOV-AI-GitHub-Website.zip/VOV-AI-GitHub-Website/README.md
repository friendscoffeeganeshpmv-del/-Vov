# VOV AI — GitHub Website

A polished multi-page, animated showcase website for the VOV AI local AI builder project.

## Included
Home, About, Features, AI Builder, Hardware, Architecture, Demo and Gallery.

## Technology
Plain HTML, CSS and JavaScript. No build step and no API key required for the showcase site.

## GitHub Pages
1. Create a GitHub repository.
2. Upload everything in this folder.
3. Go to Settings → Pages.
4. Select Deploy from a branch.
5. Select `main` and `/ (root)`.
6. Save.

## Add your real images
Put project photos, screenshots and exhibition pictures in `assets/images/` and replace the CSS-generated visual panels or add `<img>` elements.

## Important
The visual text is based on the VOV AI project details currently available. Update model names, hardware status, team information and links before publishing if your final build differs.
